﻿function _xlOffLineThunderQtyPV(){try{vhref = "http://analytics-union.sandai.net/UPV?cf=1&gs=thunderlixian&ul="+encodeURIComponent(window.location.href)+"&rf="+encodeURIComponent(document.referrer)+"&tt="+document.domain;image1 = new Image(1,1);image1.src=vhref;} catch(e) { }}
_xlOffLineThunderQtyPV();
var _xlOffLineName=unescape("%u8FC5%u96F7%u4F1A%u5458%u9AD8%u901F%u4E0B%u8F7D%uFF08%u65E0%u9700%u6302%u673A%uFF09");
var _xlOffLineName2=unescape("%u8FC5%u96F7%u4F1A%u5458%u4E0B%u8F7D%uFF08%u65E0%u9700%u6302%u673A%uFF09");
var _xlOffLineName3=unescape("%u8FC5%u96F7%u4F1A%u5458%uFF08%u65E0%u9700%u6302%u673A%uFF09");
var _xlOffLineName4=unescape("%u8FC5%u96F7%u4F1A%u5458%u9AD8%u901F%u4E0B%u8F7D");
var _xlOffLineName5=unescape("%u8FC5%u96F7%u4F1A%u5458%u4E0B%u8F7D");
var _xlOffLineName6=unescape("%u8FC5%u96F7%u4F1A%u5458");